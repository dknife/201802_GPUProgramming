
void main (void)
{
    // write Total Color:
    gl_FragColor = vec4(0.0,0.5,1.0, 1.0);

}